<?php include("includes/header.php"); ?>

    <!-- Page Content -->
    <div class="container">

      <h1 class="my-4 text-center text-lg-center">E-Learning Bagian Tubuh Manusia</h1>

      <div class="row text-center text-lg-center col-md-12" style="display:block; margin:auto;">
        <img class="img-fluid img-thumbnail" src="images/logo.png" alt="logo">
      </div>

      <div class="my-4 text-center text-lg-center">
        <p>Selamat datang di situs edukasi yang mempelajari tentang bagian tubuh manusia</p>
        <h1>Ayo Mulai Belajar</h1>
      </div>

    </div>
    <!-- /.container -->

<?php include("includes/footer.php"); ?>