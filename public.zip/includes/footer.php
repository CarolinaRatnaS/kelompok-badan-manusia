<!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Kelompok Bagian Tubuh Manusia - 2017</p>
      </div>
      <!-- /.container -->
    </footer>

    <script src="https://www.gstatic.com/firebasejs/5.7.2/firebase.js"></script>
    <script>
      // Initialize Firebase
      var config = {
        apiKey: "AIzaSyCwjxqyMKXvtAPM3n9kV0a6P3_J7Q12_YI",
        authDomain: "elearning-bagian-tubuh-manusia.firebaseapp.com",
        databaseURL: "https://elearning-bagian-tubuh-manusia.firebaseio.com",
        projectId: "elearning-bagian-tubuh-manusia",
        storageBucket: "",
        messagingSenderId: "699639238438"
      };
      firebase.initializeApp(config);
    </script>

    <!-- Bootstrap core JavaScript -->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>
